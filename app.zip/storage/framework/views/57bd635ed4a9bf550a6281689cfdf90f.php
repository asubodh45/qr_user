<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Analytics Dashboard <?php $__env->endSlot(); ?>

    
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">

        
        <div class="bg-white rounded-2xl shadow p-5 flex items-center gap-4">
            <div class="w-12 h-12 rounded-xl bg-indigo-100 flex items-center justify-center flex-shrink-0">
                <svg class="w-6 h-6 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M17 20h5v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2h5M12 12a4 4 0 100-8 4 4 0 000 8z"/>
                </svg>
            </div>
            <div>
                <p class="text-xs text-gray-500 font-medium uppercase tracking-wide">Total Members</p>
                <p class="text-3xl font-bold text-gray-800"><?php echo e(number_format($totalMembers)); ?></p>
            </div>
        </div>

        
        <div class="bg-white rounded-2xl shadow p-5 flex items-center gap-4">
            <div class="w-12 h-12 rounded-xl bg-emerald-100 flex items-center justify-center flex-shrink-0">
                <svg class="w-6 h-6 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"/>
                </svg>
            </div>
            <div>
                <p class="text-xs text-gray-500 font-medium uppercase tracking-wide">New This Month</p>
                <p class="text-3xl font-bold text-gray-800"><?php echo e(number_format($newMembersThisMonth)); ?></p>
            </div>
        </div>

        
        <div class="bg-white rounded-2xl shadow p-5 flex items-center gap-4">
            <div class="w-12 h-12 rounded-xl bg-violet-100 flex items-center justify-center flex-shrink-0">
                <svg class="w-6 h-6 text-violet-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M3 7V5a2 2 0 012-2h2M17 3h2a2 2 0 012 2v2M3 17v2a2 2 0 002 2h2M17 21h2a2 2 0 002-2v-2"/>
                </svg>
            </div>
            <div>
                <p class="text-xs text-gray-500 font-medium uppercase tracking-wide">Total QR Scans</p>
                <p class="text-3xl font-bold text-gray-800"><?php echo e(number_format($totalScans)); ?></p>
            </div>
        </div>

        
        <div class="bg-white rounded-2xl shadow p-5 flex items-center gap-4">
            <div class="w-12 h-12 rounded-xl bg-amber-100 flex items-center justify-center flex-shrink-0">
                <svg class="w-6 h-6 text-amber-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                </svg>
            </div>
            <div>
                <p class="text-xs text-gray-500 font-medium uppercase tracking-wide">Today's Scans</p>
                <p class="text-3xl font-bold text-gray-800"><?php echo e(number_format($todayScans)); ?></p>
            </div>
        </div>
    </div>

    
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">

        
        <div class="bg-white rounded-2xl shadow p-6">
            <p class="text-xs text-gray-500 font-medium uppercase tracking-wide mb-4">Most Scanned Member</p>
            <?php if($mostScanned && $mostScanned->scans_count > 0): ?>
                <div class="flex items-center gap-4">
                    <?php $img = $mostScanned->profileImage; ?>
                    <?php if($img): ?>
                        <img src="<?php echo e(Storage::url($img->path)); ?>" alt="<?php echo e($mostScanned->name); ?>"
                             class="w-14 h-14 rounded-full object-cover border-2 border-indigo-200">
                    <?php else: ?>
                        <div class="w-14 h-14 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold text-xl">
                            <?php echo e(strtoupper(substr($mostScanned->name, 0, 1))); ?>

                        </div>
                    <?php endif; ?>
                    <div>
                        <p class="font-semibold text-gray-800 text-lg"><?php echo e($mostScanned->name); ?></p>
                        <p class="text-sm text-gray-500"><?php echo e(number_format($mostScanned->scans_count)); ?> total scans</p>
                    </div>
                    <div class="ml-auto">
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-semibold bg-indigo-100 text-indigo-700">
                            #1
                        </span>
                    </div>
                </div>
            <?php else: ?>
                <p class="text-gray-400 text-sm">No scan data yet.</p>
            <?php endif; ?>
        </div>

        
        <div class="bg-white rounded-2xl shadow p-6">
            <p class="text-xs text-gray-500 font-medium uppercase tracking-wide mb-4">Most Used Device</p>
            <?php if($mostUsedDevice): ?>
                <div class="flex items-center gap-4">
                    <div class="w-14 h-14 rounded-xl bg-violet-100 flex items-center justify-center">
                        <?php if($mostUsedDevice->device === 'Mobile'): ?>
                            <svg class="w-7 h-7 text-violet-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                      d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z"/>
                            </svg>
                        <?php elseif($mostUsedDevice->device === 'Tablet'): ?>
                            <svg class="w-7 h-7 text-violet-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                      d="M12 18h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z"/>
                            </svg>
                        <?php else: ?>
                            <svg class="w-7 h-7 text-violet-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                      d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
                            </svg>
                        <?php endif; ?>
                    </div>
                    <div>
                        <p class="font-semibold text-gray-800 text-lg"><?php echo e($mostUsedDevice->device); ?></p>
                        <p class="text-sm text-gray-500"><?php echo e(number_format($mostUsedDevice->total)); ?> scans</p>
                    </div>
                </div>
            <?php else: ?>
                <p class="text-gray-400 text-sm">No scan data yet.</p>
            <?php endif; ?>
        </div>
    </div>

    
    <div class="bg-white rounded-2xl shadow p-6 mb-6">
        <div class="flex items-center justify-between mb-4">
            <h3 class="text-base font-semibold text-gray-700">QR Scan Trend</h3>
            <span class="text-xs text-gray-400">Last 30 days</span>
        </div>
        <canvas id="scanChart" height="80"></canvas>
    </div>

    
    <div class="bg-white rounded-2xl shadow p-6">
        <h3 class="text-base font-semibold text-gray-700 mb-4">Recent QR Scan Activity</h3>

        <?php if($recentScans->isEmpty()): ?>
            <p class="text-gray-400 text-sm text-center py-8">No scan activity yet.</p>
        <?php else: ?>
            <div class="overflow-x-auto">
                <table class="w-full text-sm text-left">
                    <thead>
                        <tr class="border-b border-gray-100">
                            <th class="pb-3 pr-4 text-xs font-semibold text-gray-500 uppercase tracking-wide">Member</th>
                            <th class="pb-3 pr-4 text-xs font-semibold text-gray-500 uppercase tracking-wide">IP Address</th>
                            <th class="pb-3 pr-4 text-xs font-semibold text-gray-500 uppercase tracking-wide">Country</th>
                            <th class="pb-3 pr-4 text-xs font-semibold text-gray-500 uppercase tracking-wide">City</th>
                            <th class="pb-3 pr-4 text-xs font-semibold text-gray-500 uppercase tracking-wide">Browser</th>
                            <th class="pb-3 pr-4 text-xs font-semibold text-gray-500 uppercase tracking-wide">OS</th>
                            <th class="pb-3 pr-4 text-xs font-semibold text-gray-500 uppercase tracking-wide">Device</th>
                            <th class="pb-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Date / Time</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-50">
                        <?php $__currentLoopData = $recentScans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="hover:bg-gray-50 transition-colors">
                                
                                <td class="py-3 pr-4">
                                    <div class="flex items-center gap-2">
                                        <?php $img = $scan->user?->profileImage; ?>
                                        <?php if($img): ?>
                                            <img src="<?php echo e(Storage::url($img->path)); ?>" alt=""
                                                 class="w-8 h-8 rounded-full object-cover flex-shrink-0">
                                        <?php else: ?>
                                            <div class="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold text-xs flex-shrink-0">
                                                <?php echo e(strtoupper(substr($scan->user?->name ?? '?', 0, 1))); ?>

                                            </div>
                                        <?php endif; ?>
                                        <span class="font-medium text-gray-700 whitespace-nowrap">
                                            <?php echo e($scan->user?->name ?? '—'); ?>

                                        </span>
                                    </div>
                                </td>
                                <td class="py-3 pr-4 font-mono text-gray-600 text-xs"><?php echo e($scan->ip_address ?? '—'); ?></td>
                                <td class="py-3 pr-4 text-gray-600"><?php echo e($scan->country); ?></td>
                                <td class="py-3 pr-4 text-gray-600"><?php echo e($scan->city); ?></td>
                                <td class="py-3 pr-4">
                                    <span class="inline-flex px-2 py-0.5 rounded bg-blue-50 text-blue-700 text-xs font-medium">
                                        <?php echo e($scan->browser); ?>

                                    </span>
                                </td>
                                <td class="py-3 pr-4 text-gray-600"><?php echo e($scan->operating_system); ?></td>
                                <td class="py-3 pr-4">
                                    <span class="inline-flex px-2 py-0.5 rounded text-xs font-medium
                                        <?php echo e($scan->device === 'Mobile' ? 'bg-green-50 text-green-700' : ($scan->device === 'Tablet' ? 'bg-amber-50 text-amber-700' : 'bg-gray-100 text-gray-600')); ?>">
                                        <?php echo e($scan->device); ?>

                                    </span>
                                </td>
                                <td class="py-3 text-gray-500 whitespace-nowrap text-xs">
                                    <?php echo e($scan->scanned_at?->format('M d, Y')); ?><br>
                                    <span class="text-gray-400"><?php echo e($scan->scanned_at?->format('H:i:s')); ?></span>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>

    
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <script>
        (function () {
            const ctx = document.getElementById('scanChart').getContext('2d');

            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: <?php echo json_encode($chartData['labels'], 15, 512) ?>,
                    datasets: [{
                        label: 'QR Scans',
                        data: <?php echo json_encode($chartData['values'], 15, 512) ?>,
                        borderColor: '#6366f1',
                        backgroundColor: 'rgba(99,102,241,0.08)',
                        borderWidth: 2,
                        pointBackgroundColor: '#6366f1',
                        pointRadius: 3,
                        pointHoverRadius: 5,
                        fill: true,
                        tension: 0.4,
                    }],
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            callbacks: {
                                label: ctx => ` ${ctx.parsed.y} scan${ctx.parsed.y !== 1 ? 's' : ''}`,
                            },
                        },
                    },
                    scales: {
                        x: {
                            grid: { display: false },
                            ticks: { color: '#9ca3af', maxRotation: 45 },
                        },
                        y: {
                            beginAtZero: true,
                            ticks: {
                                color: '#9ca3af',
                                precision: 0,
                            },
                            grid: { color: '#f3f4f6' },
                        },
                    },
                },
            });
        })();
    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\subod\Desktop\laravel\qr-emp\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>